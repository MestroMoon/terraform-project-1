import requests
import os

def lambda_handler(event, context):
    # Twilio Account SID and Auth Token
    acc_id = 'your-token-id'
    acc_token = 'your-token'

    twilio_number = '+'  # Twilio Phone Number
    my_no = '+1'  # Your mobile phone number
    msgbody = 'CPU Utilisation is going over 40%. Please connect with respective owners to discuss. Msg via Twilio API'

    # Twilio API endpoint
    twilio_endpoint = f'https://api.twilio.com/2010-04-01/Accounts/{acc_id}/Messages.json'

    # Basic authentication header
    authhead = (acc_id, acc_token)

    # Data payload for the SMS
    data = {
        'From': twilio_number,
        'To': my_no,
        'Body': msgbody,
    }

    # Send the SMS using HTTP POST request
    response = requests.post(twilio_endpoint, auth=authhead, json=data)

    # Check the response status
    if response.status_code == 201:
        return {
            'statusCode': 200,
            'body': f"Message sent successfully! SID: {response.json()['sid']}"
        }
    else:
        return {
            'statusCode': response.status_code,
            'body': f"Failed to send message. Status code: {response.status_code}, Message: {response.text}"
        }
