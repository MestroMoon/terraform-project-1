# import requests

# # Twilio Account SID and Auth Token
# account_sid = 'AC73f03db4265472ea3b45ceeb03e9131a'
# auth_token = 'ef6493866725fcc620c57cb1b764272f'

# twilio_number = '18058566103' #Twilio Phone Number

# personal_number = '14375592469' # Your mobile phone number

# msgbody = 'CPU Utilisation is going over 80%. Please connect with respective owners to discuss'

# # Twilio API endpoint
# twilio_api_endpoint = f'https://api.twilio.com/2010-04-01/Accounts/{account_sid}/Messages.json'

# # Basic authentication header
# auth_header = (account_sid, auth_token)

# # Data payload for the SMS
# data = {
#     'From': twilio_number,
#     'To': personal_number,
#     'Body': msgbody,
# }

# # Send the SMS using HTTP POST request
# response = requests.post(twilio_api_endpoint, auth=auth_header, data=data)

# # # Check the response status
# # if response.status_code == 201:
# #     print(f"Message sent successfully! SID: {response.json()['sid']}")
# # else:
# #     print("Failed to send message. Status code: {response.status_code}, Message: {response.text}")